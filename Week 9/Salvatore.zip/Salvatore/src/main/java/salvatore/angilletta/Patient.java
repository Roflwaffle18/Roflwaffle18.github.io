package salvatore.angilletta;

import android.os.Parcelable;

/**
 * Created by Salvatore on 2016-11-03.
 */

public class Patient{


    public int health_id;
    public String first_name;
    public String last_name;
    public String gender;
    public String department;
    public int doctor_id;

    public Patient()
    {
        health_id = 0;
        first_name = null;
        last_name = null;
        gender = null;
        department = null;
        doctor_id = 0;
    }

    public Patient(int health_id, String first_name, String last_name, String gender, String department, int doctor_id)
    {
        this.health_id = health_id;
        this.first_name = first_name;
        this.last_name = last_name;
        this.gender = gender;
        this.department = department;
        this.doctor_id = doctor_id;
    }

    public int getHealthId(){
        return health_id;
    }

    public void setHealthId(int health_id){
        this.health_id = health_id;
    }

    public String getFirstName(){
        return first_name;
    }

    public void setFirstName(String first_name){
        this.first_name = first_name;
    }

    public String getLastName(){
        return last_name;
    }

    public void setLastName(String last_name){
        this.last_name = last_name;
    }

    public String getGender(){
        return gender;
    }

    public void setGender(String gender){
        this.gender = gender;
    }

    public String getDepartment(){
        return department;
    }

    public void setDepartment(String department){
        this.department = department;
    }

    public int getDoctorId(){
        return doctor_id;
    }

    public void setDoctorId(int doctor_id){
        this.doctor_id = doctor_id;
    }

    public String toString()
    {
        return this.health_id + "\n"
                + this.first_name + "\n"
                + this.last_name + "\n"
                + this.gender + "\n"
                + this.department + "\n"
                + this.doctor_id;
    }
}
