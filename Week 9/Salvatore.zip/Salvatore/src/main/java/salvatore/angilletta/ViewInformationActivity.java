package salvatore.angilletta;

import android.content.Context;
import android.content.Intent;
import com.github.clans.fab.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.design.widget.TabLayout;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewInformationActivity extends AppCompatActivity {
    private CommentsDataSource datasource;
    //public ArrayList<Patient> patients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_information);
        //getSupportFragmentManager().beginTransaction().replace(R.id.activity_view_information, new PageFragment(), "fragment_tag").commit();

        //toolbar is defined in layout
        Toolbar myChildToolbar = (Toolbar) findViewById(R.id.tool_bar_ViewInfo);
        setSupportActionBar(myChildToolbar);
        ActionBar ab = getSupportActionBar(); // Get a support ActionBar corresponding to this toolbar
        ab.setDisplayHomeAsUpEnabled(true);

        //set up the tabs
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        viewPager.setAdapter(new SampleFragmentPagerAdapter(getSupportFragmentManager(), ViewInformationActivity.this));
        TabLayout tabLayout = (TabLayout) findViewById(R.id.sliding_tabs);
        tabLayout.setupWithViewPager(viewPager);

        //setting up the floating action buttons
        FloatingActionButton addPatientBtn = (FloatingActionButton)findViewById(R.id.menu_item_add_patient);
        addPatientBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewInformationActivity.this, AddPatientActivity.class);
                startActivity(intent);
            }
        });
        FloatingActionButton addTestBtn = (FloatingActionButton)findViewById(R.id.menu_item_add_test);
        addTestBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewInformationActivity.this, AddTestActivity.class);
                startActivity(intent);
            }
        });
    }

    //fill the toolbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //if user selects one of the options on the toolbar
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent homeIntent = new Intent(this, SalvatoreActivity.class);
                homeIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(homeIntent);
                return true;

            case R.id.action_search:
                return true;

            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }

    public class SampleFragmentPagerAdapter extends FragmentPagerAdapter {
        final int PAGE_COUNT = 2;
        private String tabTitles[] = new String[] { "My Patients", "All Patients" };
        private Context context;

        public SampleFragmentPagerAdapter(FragmentManager fm, Context context) {
            super(fm);
            this.context = context;
        }

        @Override
        public int getCount() {

            return PAGE_COUNT;
        }
        @Override
        public CharSequence getPageTitle(int position) {

            return tabTitles[position];
        }
        @Override
        public Fragment getItem(int position) {

            return PageFragment.create(position + 1);
        }
    }
}
