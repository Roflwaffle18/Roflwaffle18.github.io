package salvatore.angilletta;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Salvatore on 2016-11-03.
 */

public class PageFragment extends Fragment {
    public static final String ARG_PAGE = "ARG_PAGE";
    private int mPage;
    private CommentsDataSource datasource;

    public static PageFragment create(int page) {
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE, page);
        PageFragment fragment = new PageFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPage = getArguments().getInt(ARG_PAGE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = null;

        if (mPage == 1) {
            view = inflater.inflate(R.layout.fragment_my_patients, container, false);

            datasource = new CommentsDataSource(this.getContext());
            datasource.open();

            List<Patient> patients = datasource.getAllPatients();
            ArrayAdapter<Patient> adapter = new ArrayAdapter<Patient>(this.getActivity(), R.layout.list_item, patients);
            ListView list = (ListView)view.findViewById(R.id.list_my_patients);
            list.setAdapter(adapter);
            datasource.close();

        } else if (mPage == 2) {
            view = inflater.inflate(R.layout.fragment_all_patients, container, false);


        }

        return view;
    }

}
