package salvatore.angilletta;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Salvatore on 2016-11-05.
 */
    public class MySQLiteHelper extends SQLiteOpenHelper {

        //tables
        public static final String TABLE_DOCTOR = "doctor";
        public static final String TABLE_PATIENT = "patient";
        public static final String TABLE_TEST = "test";

        //doctors table contents
        public static final String COLUMN_ID = "id";
        public static final String COLUMN_NAME = "name";

        //patients table contents
        public static final String COLUMN_HEALTH_ID = "health_id";
        public static final String COLUMN_FIRST_NAME = "first_name";
        public static final String COLUMN_LAST_NAME = "last_name";
        public static final String COLUMN_GENDER = "gender";
        public static final String COLUMN_DEPARTMENT = "department";
        public static final String COLUMN_DOCTOR_ID = "doctor_id";

        //tests table contents
        public static final String COLUMN_TEST_ID = "test_id";
        public static final String COLUMN_HEALTH_CARE_ID = "health_care_id";
        public static final String COLUMN_BLOOD_PRESSURE = "blood_pressure";
        public static final String COLUMN_BREATHS_PER_MINUTE = "breaths_per_minute";
        public static final String COLUMN_BLOOD_OXYGEN_LEVEL = "blood_oxygen_level";
        public static final String COLUMN_BEATS_PER_MINUTE = "breaths_per_minute";
        public static final String COLUMN_TEST_DATE = "test_date";
        public static final String COLUMN_TEST_TIME = "test_time";


        private static final String DATABASE_NAME = "health_care.db";
        private static final int DATABASE_VERSION = 1;

        // Database creation sql statement
        private static final String CREATE_DOCTOR = "create table "
                + TABLE_DOCTOR + "("
                + COLUMN_ID + " integer primary key, "
                + COLUMN_NAME + " text not null);";

        private static final String INSERT_DOCTOR = "insert into "
                + TABLE_DOCTOR + " VALUES(1, 'Dr. Salvatore');";

        private static final String CREATE_PATIENT = "create table "
                + TABLE_PATIENT + "("
                + COLUMN_HEALTH_ID + " integer primary key, "
                + COLUMN_FIRST_NAME + " text not null, "
                + COLUMN_LAST_NAME + " text not null, "
                + COLUMN_GENDER + " text not null, "
                + COLUMN_DEPARTMENT + " text not null, "
                + COLUMN_DOCTOR_ID + " integer not null, "
                + "FOREIGN KEY(doctor_id) REFERENCES doctor(id));";

        private static final String INSERT_PATIENT = "insert into "
                + TABLE_PATIENT
                + " VALUES (382911,'Joe','Moe','Female','Cardiology',1);";

        private static final String CREATE_TEST = "create table "
                + TABLE_TEST + "("
                + COLUMN_TEST_ID + " integer primary key autoincrement, "
                + COLUMN_HEALTH_CARE_ID + " integer not null, "
                + COLUMN_BLOOD_PRESSURE + " text not null, "
                + COLUMN_BREATHS_PER_MINUTE + " text not null, "
                + COLUMN_BLOOD_OXYGEN_LEVEL + " text not null, "
                + COLUMN_BEATS_PER_MINUTE + "text not null, "
                + COLUMN_TEST_DATE + "text not null, "
                + COLUMN_TEST_TIME + "text not null, "
                + "FOREIGN KEY(health_care_id) REFERENCES patient(health_id));";


        public MySQLiteHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase database) {
            database.execSQL(CREATE_DOCTOR);
            database.execSQL(INSERT_DOCTOR);
            database.execSQL(CREATE_PATIENT);
            database.execSQL(INSERT_PATIENT);
            database.execSQL(CREATE_TEST);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(MySQLiteHelper.class.getName(),
                    "Upgrading database from version " + oldVersion + " to "
                            + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_DOCTOR);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENT);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_TEST);
            onCreate(db);
        }
}
