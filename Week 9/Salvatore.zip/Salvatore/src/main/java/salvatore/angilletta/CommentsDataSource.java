package salvatore.angilletta;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import org.w3c.dom.Comment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Salvatore on 2016-11-05.
 */

public class CommentsDataSource {
    // Database fields
    private SQLiteDatabase database;
    private MySQLiteHelper dbHelper;

    private String[] allColumns_Doctor = {
            MySQLiteHelper.COLUMN_ID,
            MySQLiteHelper.COLUMN_NAME
    };
    private String[] allColumns_Patient = {
            MySQLiteHelper.COLUMN_HEALTH_ID,
            MySQLiteHelper.COLUMN_FIRST_NAME,
            MySQLiteHelper.COLUMN_LAST_NAME,
            MySQLiteHelper.COLUMN_GENDER,
            MySQLiteHelper.COLUMN_DEPARTMENT,
            MySQLiteHelper.COLUMN_DOCTOR_ID
    };

    private String[] allColumns_Test = {
            MySQLiteHelper.COLUMN_TEST_ID,
            MySQLiteHelper.COLUMN_HEALTH_CARE_ID,
            MySQLiteHelper.COLUMN_BLOOD_PRESSURE,
            MySQLiteHelper.COLUMN_BREATHS_PER_MINUTE,
            MySQLiteHelper.COLUMN_BLOOD_OXYGEN_LEVEL,
            MySQLiteHelper.COLUMN_BEATS_PER_MINUTE,
            MySQLiteHelper.COLUMN_TEST_DATE,
            MySQLiteHelper.COLUMN_TEST_TIME
    };

    public CommentsDataSource(Context context) {
        dbHelper = new MySQLiteHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public Patient createPatient(int health_id, String first_name, String last_name,
                                 String gender, String department, int doctor_id) {
        ContentValues values = new ContentValues();
        values.put(MySQLiteHelper.COLUMN_HEALTH_ID, health_id);
        values.put(MySQLiteHelper.COLUMN_FIRST_NAME, first_name);
        values.put(MySQLiteHelper.COLUMN_LAST_NAME, last_name);
        values.put(MySQLiteHelper.COLUMN_GENDER, gender);
        values.put(MySQLiteHelper.COLUMN_DEPARTMENT, department);
        values.put(MySQLiteHelper.COLUMN_DOCTOR_ID, doctor_id);

        long insertId = database.insert(MySQLiteHelper.TABLE_PATIENT, null,
                values);
        Cursor cursor = database.query(MySQLiteHelper.TABLE_PATIENT,
                allColumns_Patient, MySQLiteHelper.COLUMN_HEALTH_ID + " = " + insertId, null,
                null, null, null);
        cursor.moveToFirst();
        Patient newPatient = cursorToPatient(cursor);
        cursor.close();
        return newPatient;
    }


    public List<Patient> getAllPatients() {
        List<Patient> patients = new ArrayList<Patient>();

        Cursor cursor = database.query(MySQLiteHelper.TABLE_PATIENT,
                allColumns_Patient, null, null, null, null, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Patient patient = cursorToPatient(cursor);
            patients.add(patient);
            cursor.moveToNext();
        }
        // make sure to close the cursor
        cursor.close();
        return patients;
    }

    private Patient cursorToPatient(Cursor cursor) {
        Patient patient = new Patient();
        patient.setHealthId(cursor.getInt(0));
        patient.setFirstName(cursor.getString(1));
        patient.setLastName(cursor.getString(2));
        patient.setGender(cursor.getString(3));
        patient.setDepartment(cursor.getString(4));
        patient.setDoctorId(cursor.getInt(5));
        return patient;
    }
}
